CHANGELOG
=========

6.3
---

 * Add the component as experimental
